﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ZooProject.Types;

namespace ZooProject.Logic
{
    class Worker
    {
        private Zoo Zoo { get; set; }
        public Worker()
        {
            this.Zoo = new Zoo();
        }

        public void AddAnimal(Animal animal)
        {
            Zoo.Animals.Add(animal);
        }
        
        public Animal GetAnimal(string code)
        {
            foreach (Animal animal in Zoo.Animals)
            {
                if (animal.CheckCode(code))
                {
                    return animal;
                }
            }
            throw new Exception("Invalid code;");
        }
       
    }
}
