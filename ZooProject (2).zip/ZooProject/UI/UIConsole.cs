﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ZooProject.Logic;
using ZooProject.Types;

namespace ZooProject.UI
{
    class UIConsole
    {
        private Worker Worker { get; set; }

        public UIConsole()
        {
            this.Worker = new Worker();
        }

        public void Start()
        {
            Console.WriteLine("A.Add Animal     F.Feed Animal");
            ConsoleKey key = Console.ReadKey().Key;

            switch (key)
            {
                case ConsoleKey.A:
                    Console.Clear();
                    AddAnimal();
                    Console.Clear();
                    Start();
                    break;
                case ConsoleKey.F:
                    Console.Clear();
                    FeedAnimal();
                    break;
            }
        }

        public void FeedAnimal()
        {
            Console.Write("Code: ");
            string code = Console.ReadLine();
            
            try
            {
                 Worker.GetAnimal(code);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                FeedAnimal();
            }

            Animal animal = Worker.GetAnimal(code);
            Console.WriteLine("Which food you prefer?");
            Console.WriteLine("A.cereal  B.meat  C.dryFood D.meat  E.dryFood F.larva  G.crustaceans");


            FeedTypes feed;
            ConsoleKey key = Console.ReadKey().Key;
            
            if (key == ConsoleKey.A)
            {
                feed = FeedTypes.cereal;
            }
            else if (key == ConsoleKey.B || key == ConsoleKey.D)
            {
                feed = FeedTypes.meat;
            }
            else if (key == ConsoleKey.C || key == ConsoleKey.E)
            {
                feed = FeedTypes.dryFood;
            }
            else if (key == ConsoleKey.F)
            {
                feed = FeedTypes.larvae;
            }
            else if (key == ConsoleKey.G)
            {
                feed = FeedTypes.crustaceans;
            }
            else
            {
                feed = FeedTypes.dryFood;
            }

            Console.Clear();

            try
            {
                animal.Feed(feed);
                Console.WriteLine("Done");
                Start();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                FeedAnimal();
            }
        }

        
        public void AddAnimal()
        {
            Console.Write("Code: ");
            string code = Console.ReadLine();
            Console.Clear();

            AnimalType type;
            Console.WriteLine("Type: L.Lion  D.Dog  F.Fish");
            ConsoleKey key = Console.ReadKey().Key;

            switch (key)
            {
                case ConsoleKey.L:
                    type = AnimalType.lion;
                    break;
                case ConsoleKey.F:
                    type = AnimalType.fish;
                    break;
                default:
                    type = AnimalType.dog;
                    break;
            }

            Console.Clear();
            Console.Write("Stomach size: ");
            int stomach = int.Parse(Console.ReadLine());

            Animal animal;
            switch (type)
            {
                case AnimalType.lion:
                    animal = new Lion(type, code, stomach);
                    break;
                case AnimalType.dog:
                    animal = new Dog(type, code, stomach);
                    break;
                default :
                    animal = new Fish(type, code, stomach);
                    break;
            }

            Worker.AddAnimal(animal);
        }
    }
}
