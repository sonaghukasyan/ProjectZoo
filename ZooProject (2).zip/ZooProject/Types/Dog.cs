﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Timers;

namespace ZooProject.Types
{
    class Dog : Animal
    {
        public Dog(AnimalType type, string code, int stomach)
        {
            this.Type = type;
            this.Code = code;
            this.Stomach = stomach;
            this.MaxSize = stomach;

            this.FeedTypes = new List<FeedTypes>() { Types.FeedTypes.cereal, Types.FeedTypes.meat, Types.FeedTypes.dryFood };
            this.IsAlive = true;
            this.IsHungry = false;
            this.GetHungry();
        }

        public override void Feed(FeedTypes food)
        {

            base.Feed(food);

            for (int i = 0; i < this.FeedTypes.Count; i++)
            {
                if (FeedTypes[i] == food)
                {
                    this.Stomach = this.MaxSize;
                    return;
                }
            }
            throw new Exception("Not suitable food");
        }

        public override void GetHungry()
        {
            base.GetHungry();

            Timer timer = new Timer(TimeSpan.FromSeconds(10).TotalMilliseconds);

            timer.AutoReset = true;
            timer.Elapsed += Timer_Elapsed;
            timer.Start();

            void Timer_Elapsed(object sender, ElapsedEventArgs e)
            {
                this.Stomach -= 50;
                GetHungry();
            }
        }

        public override void State()
        {
            base.State();

            if(this.Stomach <= 20)
            {
                this.IsHungry = true;
            }
            else
            {
                this.IsHungry = false;
            }
        }
        
    }
}

