﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZooProject.Types
{
    public abstract class Animal
    {
        protected int Stomach;
        protected int MaxSize;
        protected string Code;

        public bool IsAlive;
        public bool IsHungry;

        public AnimalType Type { get; set; }
        public List<FeedTypes> FeedTypes { get; set; }

        public virtual void Feed(FeedTypes food)
        {
            if (this.IsAlive == false)
            {
                throw new Exception("This animal is dead and cannot eat.");
            }
            else if (this.IsHungry == false)
            {
                throw new Exception("This animal is not hungry.");
            }

        }

        public virtual void GetHungry()
        {
            this.State();

            if (!this.IsAlive)
            {
                return;
            }
        }

        public virtual void State()
        {
            if(this.Stomach <= 0)
            {
                this.IsAlive = false;
            }
        }

        public virtual bool CheckCode(string code)
        {
            return this.Code == code;
        }
    }
}
