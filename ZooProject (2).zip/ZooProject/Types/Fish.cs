﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace ZooProject.Types
{
    class Fish : Animal
    {
        public Fish(AnimalType type, string code, int stomach)
        {
            this.Type = type;
            this.Code = code;
            this.Stomach = stomach;
            this.MaxSize = stomach;

            this.FeedTypes = new List<FeedTypes>() { Types.FeedTypes.larvae, Types.FeedTypes.crustaceans};
            this.IsAlive = true;
            this.IsHungry = false;
            this.GetHungry();
        }

        public override void Feed(FeedTypes food)
        {
            base.Feed(food);

            for (int i = 0; i < this.FeedTypes.Count; i++)
            {
                if (FeedTypes[i] == food)
                {
                    this.Stomach = this.MaxSize;
                    return;
                }
            }
            throw new Exception("This fish cannot eat " + food);
        }


        public override void GetHungry()
        {
            base.GetHungry();

            Timer timer = new Timer(TimeSpan.FromSeconds(5).TotalMilliseconds);

            timer.AutoReset = true;
            timer.Elapsed += Timer_Elapsed;
            timer.Start();

            void Timer_Elapsed(object sender, ElapsedEventArgs e)
            {
                this.Stomach -= 1;
                GetHungry();
            }
        }

        public override void State()
        {
            base.State();

            if (this.Stomach <= 5)
            {
                this.IsHungry = true;
            }
            else
            {
                this.IsHungry = false;
            }
        }
    }
}
