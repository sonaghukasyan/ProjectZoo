﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZooProject.Types
{
    public enum FeedTypes
    {
        cereal,
        meat,
        crustaceans,
        larvae,
        dryFood
    }
}
